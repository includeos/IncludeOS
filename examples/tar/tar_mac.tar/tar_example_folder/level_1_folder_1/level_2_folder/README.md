### IncludeOS Demo Service

```
make
./run.sh
```

This demo-service should start an instance of IncludeOS that brings up a minimal web service on port 80 with static content.
Note: Remember to run the bridge creation script for networking to work on qemu (by running `etc/create_bridge.sh`).
